Morgan Multimedia Stream Switcher v0.99
---------------------------------------

[Info]
http://www.morgan-multimedia.com/mmswitch/index.htm

[Content]
- MMSwitcher : DirectShow Filter
- MMSwitch   : WMP 9 Plug-in
- MMAVILng   : Post-Mortem AVI patcher

[Licence]
QPL 1.0
http://www.opensource.org/licenses/qtpl.php
http://www.trolltech.com/licenses/qpl.html
http://www.trolltech.com/licenses/qpl-annotated.html

Copyright � 1990 - 2002 Morgan Multimedia