#define FILEVER        3,1,0,252
#define PRODUCTVER     3,1,0,252
#define STRFILEVER     "3, 1, 0, 252\0"
#define STRPRODUCTVER  "3, 1, 0, 252\0"
