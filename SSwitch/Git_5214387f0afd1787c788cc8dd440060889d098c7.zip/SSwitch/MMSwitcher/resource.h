//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MMSwitchprop.rc
//
#define VERSION_RES_MINOR_VER           0
#define VERSION_RES_BUILD               0
#define VER_DEBUG                       0
#define VERSION_RES_MAJOR_VER           1
#define IDD_DIALOG1                     101
#define IDB_BITMAP1                     102
#define IDD_DIALOG2                     102
#define IDB_ICONSTREAM0                 104
#define IDB_ICONSTREAM1                 105
#define IDB_ICONSTREAM2                 106
#define IDB_ICONSTREAM3                 107
#define IDS_PREFORMAT                   301
#define IDS_PREMAJOR                    302
#define IDS_PRESUB                      303
#define IDS_NOTYPE                      304
#define IDS_ANYTYPE                     305
#define IDS_TITLE                       306
#define IDC_MEDIALIST                   1001
#define IDC_BUTTON1                     1002
#define IDB_BITMAPMORGAN                1003
#define IDC_LANGLIST                    1004
#define IDC_EDIT                        1005
#define IDC_DEFLANGLIST                 1006
#define VERSION_RES_LANGUAGE            0x409
#define VERSION_RES_CHARSET             1252

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
